import grpc
from .grpc_interface import robot_pb2
from .grpc_interface import robot_pb2_grpc

from contextlib import contextmanager

from . import shareobj


class Controller():
    def __init__(self, address: str):
        # init stub
        shareobj.channel = grpc.insecure_channel(address)
        shareobj.stub = robot_pb2_grpc.MachineControllerStub(shareobj.channel)

        self.address = address
        self.__stub = shareobj.stub

    def close(self):
        # clear stub
        shareobj.channel.close()
        shareobj.channel = None
        shareobj.stub = None


@contextmanager
def run_controller(address: str):
    controller = Controller(address)
    try:
        yield controller
    finally:
        controller.close()
