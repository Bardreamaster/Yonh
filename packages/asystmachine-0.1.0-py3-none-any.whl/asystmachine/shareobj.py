from .grpc_interface import robot_pb2_grpc

channel = None
stub: robot_pb2_grpc.MachineControllerStub = None
