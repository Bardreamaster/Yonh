from typing import List
from dataclasses import dataclass
from . import shareobj
from .grpc_interface import robot_pb2
from google.protobuf import empty_pb2


@dataclass()
class JointStatus:
    position: float
    velocity: float
    torque: float
    is_enable: bool


@dataclass()
class JointOption:
    @dataclass()
    class Limit:
        min: float
        max: float
    name: str
    max_velocity: float
    max_acceleration: float
    limit: Limit


class Joint:
    def __init__(self, id):
        self.id = id

    def go_position(self, value: float):
        cmd = robot_pb2.MovePositionCommand()
        cmd.joint.id = self.id
        cmd.position = value
        shareobj.stub.MoveJointPosition(cmd)

    def go_velocity(self, value: float):
        cmd = robot_pb2.MoveVelocityCommand()
        cmd.joint.id = self.id
        cmd.velocity = value
        shareobj.stub.MoveJointVelocity(cmd)

    def enable(self):
        cmd = robot_pb2.EnableCommand()
        cmd.joint.add().id = self.id
        shareobj.stub.EnableJoint(cmd)

    def disable(self):
        cmd = robot_pb2.DisableCommand()
        cmd.joint.add().id = self.id
        shareobj.stub.DisableJoint(cmd)

    def stop(self):
        cmd = robot_pb2.StopCommand()
        cmd.joint.add().id = self.id
        shareobj.stub.StopJoint(cmd)

    def get_option(self) -> JointOption:
        joint_m = robot_pb2.Joint()
        joint_m.id = self.id
        res = shareobj.stub.GetJointOption(joint_m)

        limit = JointOption.Limit(min=res.limit.min, max=res.limit.max)
        return JointOption(
            name=res.name, max_acceleration=res.maxAcceleration, max_velocity=res.maxVelocity, limit=limit)

    def get_status(self) -> JointStatus:
        joint_m = robot_pb2.Joint()
        joint_m.id = self.id
        res_iterator = shareobj.stub.GetJointStatus(joint_m)
        res = res_iterator.next()

        return JointStatus(position=res.position, velocity=res.velocity, torque=res.torque, is_enable=res.isEnable)

    def set_origin(self):
        cmd = robot_pb2.SetOriginCommand()
        cmd.joint.add().id = self.id
        shareobj.stub.SetJointOrigin(cmd)

    def set_option(self, option: JointOption):
        cmd = robot_pb2.SetOptionCommand()
        cmd.joint.id = self.id
        cmd.option.name = option.name
        cmd.option.maxVelocity = option.max_velocity
        cmd.option.maxAcceleration = option.max_acceleration
        cmd.option.limit.min = option.limit.min
        cmd.option.limit.max = option.limit.max
        shareobj.stub.SetJointOption(cmd)


def get_joints() -> List[Joint]:
    res = shareobj.stub.GetJointList(empty_pb2.Empty())
    joint_list = []
    for j in res.joint:
        joint_list.append(Joint(j.id))

    return joint_list
